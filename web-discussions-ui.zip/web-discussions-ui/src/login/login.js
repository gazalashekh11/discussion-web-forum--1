import React from 'react';
import styles from './login.css';

class Login extends React.Component {
  constructor() {
    super();
    this.state = {
      userName: "",
      channelQuery:"",
      accessRW:"",
      currentOrg:"",
      authToken: "",
      schoolId:""
    }
    this.handleChange = this.handleChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
    this.channelQueryRef = React.createRef();
  }
  handleChange(event){
    const target = event.target;
    const name = target.name;
    this.setState({
      [name]: target.value
    });
   }
  handleSubmit(event) {
    event.preventDefault();
    
    this.props.onLogin(
      event,
      {
        userName: this.state.userName, 
        channelQuery: JSON.stringify(JSON.parse(this.channelQueryRef.current.value)),//this.state.channelQuery, 
        accessRW: this.state.accessRW,
        currentOrg: this.state.currentOrg,
        enableCreate : this.state.enableCreate,
        authToken: this.state.authToken,
        schoolId: this.state.schoolId
      }
      
    );
  }
 enterInitialData(){
   this.setState({
      userName: "nilesh.suryavanshi@ness.com",
      //channelQuery:'{"users":["b920dfed-f66d-4660-aa3c-6095336c6e14"],"organization":[{"id":"58f4859029c5632e00f5b20f","orgType":"school"}]}',
      accessRW:"",
      currentOrg:'{"id":"5c46fd3a67aadd3e068e3bd6","orgType":"coursesection"}',
      authToken: 'a8c8ed7d-2892-42e8-8b59-0afb2de78a6b',
      schoolId:'58f4859029c5632e00f5b20f'
   })
   this.channelQueryRef.current.value = JSON.stringify(
     {"users":["b920dfed-f66d-4660-aa3c-6095336c6e14"],"organization":[{"id":"58f4859029c5632e00f5b20f","orgType":"school"}]},
     null,
     4
   )
 }
  render() {
    return (
     
      <div>
        <button onClick={this.enterInitialData.bind(this)}>Data</button>
        <form onSubmit={this.handleSubmit} className={styles.loginForm}>
          <table>
           <tbody> 
           <tr className={styles.fieldsSection}>
             <td>
             <label 
              htmlFor="User" className={styles.labelText}>
              User Name              
            </label>
            </td>
              <td>
            <input 
              className={styles.inputUser} 
              type="text" 
              id="userName" 
              name="userName" 
              placeholder="User Name" 
              value={this.state.userName}
              onChange={this.handleChange} 
                            
            />
            </td>
            </tr>
            <tr>
              <td>
            <label 
              htmlFor="User" className={styles.labelText}>
              Auth Token             
            </label>
            </td>
            <td>
            <input 
              className={styles.inputUser} 
              type="text" 
              id="authToken" 
              name="authToken" 
              placeholder="Auth token" 
              value={this.state.authToken}
              onChange={this.handleChange} 
                            
            />
            </td>
            </tr>
            <tr className ={styles.selectChannel}>
              <td>
              <label 
                  htmlFor="schoolId" 
                  className={styles.labelText}>
                  School Id
              </label>
              </td>
                <td>
              <input name="schoolId" 
              type="text" 
              className={styles.inputUser} 
              value={this.state.schoolId} 
              onChange={this.handleChange} />
              </td>
            </tr>
            <tr className ={styles.selectChannel}>
              <td>
              <label 
                  htmlFor="currentOrg" 
                  className={styles.labelText}>
                  Organization to which a new channel should be added
              </label>
              </td>
                <td>
              <input name="currentOrg" 
              type="text" 
              className={styles.inputUser} 
              value={this.state.currentOrg} 
              onChange={this.handleChange} />
              </td>
            </tr>
            <tr className ={styles.selectChannel}>
              <td>
              <label 
                  htmlFor="channelQuery" 
                  className={styles.labelText}>
                  Query with users and organizations 
              </label>
              </td>
              <td>
              <textarea name="channelQuery" 
              type="text" 
              className={styles.inputUser} 
              ref = {this.channelQueryRef}
              //value={this.state.channelQuery} 
              //onChange={this.handleChange} >
              >
              </textarea>
              </td>

            </tr>

              <tr>
                <td>
                <label 
                  htmlFor="enableCreate" className={styles.labelText}>
                  Enable Create/Delete
                </label>
                </td>
                <td>
                <select 
                  name="enableCreate"
                  value={this.state.enableCreate} 
                  onChange={this.handleChange} 
                  className="form-control"
                >
                  <option value="">Select an Option</option>
                  <option value="1">user</option>
                  <option value="2">channels</option>
                  <option value="3">user/channels</option>
                  <option value="4">Delete user</option>
                  <option value="5">Delete channel</option>
                  <option value="0">None</option>
                </select>
                </td>
              </tr>

            
            <tr className={styles.buttonSection}>
              <td>
              {/*<button className={styles.cancelButton} >Cancel</button>*/}
              <button 
                className = {styles.loginBtn} 
                type="submit" 
                value="Submit"
              >Go</button>
              </td>
            </tr>
            </tbody>
            </table>
        </form>
        
      </div>
    );
  }
}

export default Login;