var config = {
    //host:"http://dev.use.daf.pulse.pearson-intl.com"
    host:"http://localhost:3000/"
}
export default config;