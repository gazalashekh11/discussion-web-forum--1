import React from 'react';
import styles from "./searchMsg.css";


function SearchMsg(props){
    
    return(
        <div className = {styles.searchSection}>
            {props.curActiveChn.name && <form>
                <input type="text" className={styles.searchTerm} placeholder="Search for messages..." onChange={event => props.handleSearchInputChange(event)}/>
                      <button type="submit" className={styles.searchButton} onClick={event => props.searchMessages(event,props.searchQuery)} value = {props.searchQuery}>
                      Go
                     </button>
          </form>}
          </div>
    )
}

export default SearchMsg;