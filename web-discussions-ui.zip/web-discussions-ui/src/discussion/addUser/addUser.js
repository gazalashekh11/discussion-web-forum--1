import React from 'react';
import styles from './addUser.css';

class AddUser extends React.Component {
    constructor(){
        super();
        this.state = {
            checkboxes: [],
            filter: 'ALL',
            enableAddBtn:false
        };
        this.renderCheckboxes = this.renderCheckboxes.bind(this);          
    }
    toggleCheckbox(index) {
        const {checkboxes} = this.state;
        checkboxes[index].checked = !checkboxes[index].checked;
        for (let i = 0; i < checkboxes.length; i++) {
            if(checkboxes[i].checked === false || checkboxes[i].checked === undefined){
                this.setState({
                    enableAddBtn: false
                })
            }else{
                this.setState({
                    enableAddBtn: true
                })
                break;
            }
        }
    }
    componentWillMount(){
        const component = this;
        let checkboxes = this.props.users.filter(user=>{
            return !component.props.channelUsers.some((el) => {
                return user.userId === el.userId;
            })
        })
        this.setState({
            checkboxes : checkboxes
        });
    }
    addUserToChannel(){
        if(!this.state.enableAddBtn){
            return;
        }
        this.props.handleAddNewUser({
            users: this.state.checkboxes.filter(checkbox=>checkbox.checked), 
            channelId: this.props.channel._id
        });
        
        this.props.closePopup();
    }
    renderCheckboxes(userName) {
        const component = this;
        return this.state.checkboxes
            .map((checkbox, index) =>{
                return(
                    checkbox.id!==userName?
                        <li key={checkbox.id}>
                            <label>
                                <input
                                    type="checkbox"
                                    checked={checkbox.checked}
                                    onChange={component.toggleCheckbox.bind(this, index)}
                                />
                                {checkbox.name}
                            </label>
                        </li>
                        :
                        null
                )
            }
                
                
            );
    }
    render() {
        return (
            <div>
                <div className={styles.modalHeader}>
                    <span aria-hidden="true" className={styles.closeModal} onClick={this.props.closePopup}>X</span>
                   {this.state.checkboxes.length ? <h4 className={styles.titleModal}>  Add User </h4>
                   :
                   <h4 className={styles.titleModal}>  No User to add </h4>
                  }
                    
                </div>
                <div className={styles.main}>
                    <div className={styles.fieldsSection}>
                        <ul>
                            {this.renderCheckboxes(this.props.userName)}
                        </ul>   
                    </div>
                    {this.state.checkboxes.length ?
                    <div className={styles.buttonSection}>
                        <button className={styles.cancelButton} onClick={this.props.closePopup}>Cancel</button>
                        <button className={ this.state.enableAddBtn ? styles.addUserSumbit:styles.disabledButton} onClick={this.addUserToChannel.bind(this)}>Add</button>
                    </div>:''
                    }
                </div>
            </div>
        );
    }
}

export default AddUser;