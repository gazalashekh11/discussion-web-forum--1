import React from 'react';
import styles from './users.css';
import CircularProgress from '@material-ui/core/CircularProgress';

function Users(props) {
    return(
        <div className={styles.tocMembersSection}>
            <header className={styles.title}>
                <h3>Users
                    <span className={
                            (!props.curActiveChn.isPrivate && !props.curActiveChn.implicit)
                                &&
                            (props.enableCreate === 1 || props.enableCreate === 3) 
                            ?  
                            styles.popupOpenClose
                            :
                            styles.hidden
                        } 
                        onClick={props.openNewUser}>
                        +
                    </span>
                </h3>
            </header>
            {props.userListLoader && <div className={styles.loader}>
            <CircularProgress  size={25}/>
            </div>}
            {!props.userListLoader &&
                <ul className={styles.tocMemberList}>
                    {
                        props.users.map(
                            (object, i) => 
                            <li  className={props.activeUser === i ? styles.active : ''} 
                            > 
                                <span 
                                    key={object.id} 
                                    onClick={event=>props.handleUserClick(event, object, i)}
                                >
                                    {object.name}
                                </span>
                                <span 
                                    onClick={event=>props.handleUserDelete(event, object, i)}
                                >
                                    -
                                </span>
                            </li>
                        )
                        }
                </ul>
            }
        </div>
    )
}

export default Users;
