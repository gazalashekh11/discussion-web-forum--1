import eventsUtil from './eventsUtil';

function ListData(component, NotificationManager){
    component.socket.on(eventsUtil.listChannels,function(channels){
        component.setState({
            topicListLoader : false
        }) 
        component.setState({
            channels: channels
        });
    });
    component.socket.on(eventsUtil.listChannelsInitial,function(channels){ 
        component.setState({
            topicListLoader : false
        }) 
        component.setState({
            channels: channels,
            curActiveChn: typeof(channels[0]) !== undefined ? channels[0] : {},
            actvTopicName: (typeof(channels[0]) !== undefined ? channels[0] : {}).name,
            activeChannel: 0
        });
    });
    
    component.socket.on(eventsUtil.listChannelUsers,function(users){
        component.setState({
            channelUsers: users,
            userListLoader : false
        });
        // for(let i = 0;i<users.length;i++){
        //     if(users[i].username === component.props.userName){
        //         component.setState({
        //             activeUser: i
        //         });
        //     }
        // }
    });
    component.socket.on(eventsUtil.listPosts,function(messages){
        console.log(messages);
        component.setState({
            postSecLoader : false
        }) 
        if(component.state.lazyLoadCall){
            if(messages.length){
                var temp =[];
                temp = component.state.posts;
                temp.reverse();
                messages.reverse();
                for(let i = 0; i<messages.length;i++){
                    temp.push(messages[i]);
                }
               temp.reverse();
                component.setState({
                    posts: temp
                });
            }else{
                component.setState({
                    noDataOnLazyLd: true
                });
                
                return;
            }
        }else{
            component.setState({
                posts: messages,
                noDataOnLazyLd: false
            });
        }
    });
    component.socket.on(eventsUtil.addListPosts,function(messages){ 
        // console.log("added message",messages);
        // var temp =[];
        // temp = component.state.posts;
        // for(let i = 0; i<messages.length;i++){
        //     temp.push(messages[i]);
        // }
        component.setState({
            posts: messages,
            postSecLoader : false,
            noDataOnLazyLd: false
        });
    });
    component.socket.on(eventsUtil.listSearchPosts, function(messages){
        console.log("searched msg:",messages);
        if(component.state.lazyLoadCall){
            if(messages.length){
                var temp =[];
                temp = component.state.posts;
                temp.reverse();
                messages.reverse();
                for(let i = 0; i<messages.length;i++){
                    temp.push(messages[i]);
                }
               temp.reverse();
                component.setState({
                    posts: temp
                });
            }else{
                return;
            }
        }else{
            component.setState({
                posts: messages
            });
        }
    });
    component.socket.on(eventsUtil.privateChannel, function(chanel){
        if(typeof(component.state.curActiveChn._id) !== "undefined"){
            if(component.state.authenticated){
                component.socket.emit(eventsUtil.unsubscribe,{channelId: component.state.curActiveChn._id});
            }
        }
        component.setState({curActiveChn:chanel});
        if(component.state.authenticated){
            component.socket.emit(eventsUtil.subscribe,{channelId: chanel._id});
            component.socket.emit(eventsUtil.getPosts, {channelId: chanel._id});
        }
    });

    component.socket.on(eventsUtil.listUsers,function(users){ 
        if(!users.error){
            component.setState({
                users: users
            });
        }
    });
    component.socket.on("dferror",function(data){
        NotificationManager.error(data, 'Error', 5000, () => {
            //alert('callback');
        });
    })
}

export default ListData;