import React from 'react';
import styles from './description.css';
import Close from '@material-ui/icons/Clear';
import Moment from 'react-moment';
import moment from 'moment-timezone';
import mom from 'moment';
var tz = moment.tz.guess();
var createDate = '';
function Description(props){
    if(props.curActiveChn._id){
        createDate = parseInt(props.curActiveChn._id.toString().substring(0,8), 16 ) * 1000;
    }
    return(
        <div className={styles.descriptionSec}>
            <div className={styles.header}>
                <span className={styles.title}> About this discussion</span>
                <span className={styles.close}>
                        <Close
                        name='clear'
                        size={32}
                        onClick = {props.showDescriptionSec}
                        />
                </span>
            </div>
            <div className={styles.dateCreated}>
                <span className={styles.dateTitle}>Date created: </span>
                <span className={styles.date}><Moment tz={tz}>{createDate}</Moment></span>
            </div>
            <div className={styles.topicDisussion}>{props.curActiveChn.name}</div>
            <div className = {styles.statement}>
                <div className={styles.statementHeading}>
                    Discussion Statement
                </div>
                <div className={styles.stateDiscription}>
                  {props.curActiveChn.description}
                </div>
            </div>
        </div>
    )
}

export default Description;