import React from 'react';
import styles from "./topics.css";
import CircularProgress from '@material-ui/core/CircularProgress';

function Topics(props) {
    return(
        <div className={styles.tocDiscussionSection}>
            <header className={styles.title}>
                <h3>Topics
                    <span 
                        className={
                            (props.enableCreate === 2 || props.enableCreate === 3) 
                            ? 
                            styles.popUpOpenClose 
                            : 
                            styles.hidden
                        } 
                        onClick={props.openNewTopicPopup}>
                        +
                    </span> 
                 </h3>
            </header>
            {props.topicListLoader && <div className={styles.loader}>
            <CircularProgress  size={25}/>
            </div>}
            {!props.topicListLoader &&
                <ul className={styles.tocDiscussionList}>
                    {
                        props.channels.map(
                            (object, i) => 
                            <li  className={props.activeChannel === i ? styles.active : ''}
                                key={object._id} 
                                onClick={event=>props.handleTopicClick(event, object, i)}
                            > 
                                {object.name} 
                                <span 
                                    className={
                                        (props.enableCreate === 5) 
                                        ? 
                                        styles.deleteTopic 
                                        : 
                                        styles.hidden
                                    } 
                                    onClick={event=>props.handleChannelDelete(event, object, i)}>
                                    x
                                </span> 
                            </li>
                            
                        )
                        }
                </ul>
            }
        </div>
    )
}

export default Topics;
