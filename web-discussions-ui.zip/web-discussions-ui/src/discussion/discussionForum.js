import React from 'react';
import styles from './discussionForum.css';
import openSocket from 'socket.io-client';
import configData from '../discussion-ui-config.js';
import eventsUtil from "./eventsUtil";
import Topics from "./topics/topics";
import Users from "./users/users";
import Posts from "./posts/posts";
import PostBox from "./postBox/postbox";
import AddTopic from "./addTopic/addTopic";
import AddUser from "./addUser/addUser";
import Popup from "./popup/popup";
import Description from "./description/description";
import ListData from "./listData";
import {NotificationContainer, NotificationManager} from 'react-notifications';
import 'react-notifications/lib/notifications.css';

class DiscussionForum extends React.Component {
    constructor() {
        super();
        this.state = {
            userName: "",
            channelQuery:"",
            accessRW:"",
            currentOrg:"",
            authToken: "",
            channels: [],
            posts: [],
            channelUsers: [],
            users:[],
            curActiveChn: {},
            showPopup: false,
            showUserPopup: false,
            expandMsgSec:false,
            showDescription:false,
            searchQuery: '',
            activeChannel : -1,
            activeUser : -1,
            skip:0,
            checkScrollPos:false,
            lazyLoadCall:false,
            noDataOnLazyLd :false,
            readMsgList:[],
            postSecLoader:true,
            topicListLoader:true,
            userListLoader:true,
            actvTopicName : ''
        }
        this.socket = openSocket((configData.host).toString(), {transports: ['websocket']});
        this.connectToServer = this.connectToServer.bind(this);
        this.getChannels = this.getChannels.bind(this);
        this.handleTopicClick = this.handleTopicClick.bind(this);
        this.handleUserClick = this.handleUserClick.bind(this);
        this.addMessage = this.addMessage.bind(this);
        this.handleAddNewTopic = this.handleAddNewTopic.bind(this);
        this.handleAddNewUser = this.handleAddNewUser.bind(this);
        this.openNewTopicPopup = this.openNewTopicPopup.bind(this);
        this.handleChannelDelete = this.handleChannelDelete.bind(this);
        this.openNewUser = this.openNewUser.bind(this);
        this.expandPostSec = this.expandPostSec.bind(this);
        this.showDescriptionSec = this.showDescriptionSec.bind(this);
        this.handleSearchInputChange = this.handleSearchInputChange.bind(this);
        this.searchMessages = this.searchMessages.bind(this);
        this.handlePostScroll = this.handlePostScroll.bind(this);
        this.readUnreadMsg = this.readUnreadMsg.bind(this);
        this.handleUserDelete = this.handleUserDelete.bind(this);
        console.log("build");
    }
    connectToServer(){
        if(this.props.authToken !=="" && this.props.userName !==""){
            let component = this;
            //request for authentication
            this.socket.emit('authentication', {
                    authToken: this.props.authToken,
                    username: this.props.userName,
                    enableCreate: this.props.enableCreate,
                }
            );
            //Get data if we get authenticated from server
            this.socket.on('authenticated', function(data) {
                component.setState({
                    authenticated: true
                });
                component.props.setEnableCreate(data.enableCreate);
                component.getChannels();
                component.getUsers();
                
            });

            this.socket.on('unauthorized', function(err){ 
                NotificationManager.error(err, 'Error', 5000, () => {
                    //alert('callback');
                });
                component.socket.emit("disconnect");
                component.setState({
                    authenticated: false
                })
            });

            this.socket.on('disconnect',function(){
                if(component && component.state.authenticated){
                    component.connectToServer();
                }
            })
        }
        
    }
    openNewTopicPopup(){
        this.setState({
            showPopup: true
        })
    }
    openNewUser(){
        this.setState({
            showUserPopup: true
        })
    }
    handleAddNewTopic(obj){
        if(this.state.authenticated){
            obj.organization = this.props.channelQuery;
            obj.currentOrg = this.props.currentOrg;
            this.socket.emit(
                eventsUtil.addChannel,
                obj
            );
        }
    }
    handleAddNewUser(obj){
        if(this.state.authenticated){
            this.socket.emit(
                eventsUtil.addUserToChannel,
                obj
            )
        }
    }
    togglePopup(){
        this.setState({
            showPopup: !this.state.showPopup
        });
    }
    toggleUserPopup(){
        this.setState({
            showUserPopup: !this.state.showUserPopup
        });
    }
    handleTopicClick(event, channel, i){
         if(this.state.authenticated){
            if(typeof(this.state.curActiveChn._id) !== "undefined"){
                this.socket.emit(eventsUtil.unsubscribe,{channelId: this.state.curActiveChn._id});
            }
            this.socket.emit(eventsUtil.subscribe,{channelId: channel._id});
            this.setState({
                curActiveChn: channel,
                actvTopicName:channel.name,
                searchQuery:'',
                posts:[], //prevent lazy load states
                lazyLoadCall:false,                
                skip:0,
                checkScrollPos:false,
            });
            this.getMessages(channel._id, 0);
            this.getChannelUsers(channel._id);
            this.setState({
                activeChannel: i,
                activeUser: -1,
                postSecLoader:true,
                userListLoader:true
            });
        }
    }
    handleUserClick(event, user, i){
        if(this.state.authenticated){
            this.socket.emit(
                eventsUtil.createOrGetPrivateChannel,
                {"userTo":user.username, "userFrom":this.props.userName}
            );
            this.setState({
                activeUser: i,
                postSecLoader:true,
                actvTopicName:user.name
            })
        }
        
    }
    handleUserDelete(event, user, i){
        if(this.state.authenticated){
            this.socket.emit(
                eventsUtil.deleteUserFromChannel,
                {"user":user, "channelId": this.state.curActiveChn._id}
            );
        }
    }

    handleChannelDelete(event, channel, i){
        if(this.state.authenticated){
            if(typeof(channel._id) !== "undefined"){
                this.socket.emit(eventsUtil.unsubscribe,{channelId: channel._id});
            }
            this.socket.emit(eventsUtil.deleteChannel,{channelId: channel._id});
        }
    }
    
    addMessage(msg, parent){
        if(this.state.authenticated){
            this.setState({//prevent lazy load states
                // posts:[],
                lazyLoadCall:false,
                skip:0,
                searchQuery:'',
                checkScrollPos:false,
                postSecLoader:true,
            });
            this.socket.emit(
                eventsUtil.addPost, 
                {
                    channelId: this.state.curActiveChn._id,
                    post:msg,
                    parent: parent
                    // limit:1,
                    // skip:0
                }
            );
        }
    }
    getUsers(){
        let component = this;
        if(this.state.authenticated){
            this.socket.emit(
                eventsUtil.getUsers,
                {org: component.props.currentOrg, schoolId: component.props.schoolId}
            )
        }
    }
    getChannelUsers(channelId){
        if(this.state.authenticated){
            this.socket.emit(
                eventsUtil.getChannelUsers,
                {channelId: channelId}
            )
        }
    }
    getMessages(channelId, skip){
        if(this.state.authenticated){
            this.setState(
                {
                    postSecLoader:true
                }
            )
            this.socket.emit(
                eventsUtil.getPosts, 
                {   
                    channelId: channelId, 
                    limit:5,
                    skip:skip
                }
            );
        }
    }
    getChannels(){
        let component = this;  
        if(this.state.authenticated){
            this.socket.emit(eventsUtil.getChannels,
                {
                    query: component.props.channelQuery, 
                    currentOrg: component.props.currentOrg,
                    schoolId: component.props.schoolId,
                    initial: true
                }
            );
        }
    }
    componentDidUpdate(prevProps){
        if(prevProps.authToken !== this.props.authToken){
            this.connectToServer();
        }
    }
    componentDidMount(){
        this.connectToServer();
        ListData(this, NotificationManager);
    }
    expandPostSec(){
        this.setState({
            expandMsgSec : !this.state.expandMsgSec
        });
        if(this.state.showDescription){
            this.setState({
                showDescription : false
            })
        }
    }
    showDescriptionSec(){
        this.setState({
            showDescription : !this.state.showDescription
        })
        if(!this.state.showDescription){
            this.setState({
                expandMsgSec : true
            });
        }
        console.log("curActiveChn",this.state.curActiveChn)
    }

    //search
   
    handleSearchInputChange(e){
          this.setState({
            searchQuery:e.target.value,
            skip:0,
            // posts:[],//prevent lazy load states
            lazyLoadCall:false,
            checkScrollPos:false,
          });       
          if(e.target.value.length >= 3){
              this.searchMessages(e,e.target.value);
          } 
        if(e.target.value.length === 0){
            this.getMessages(this.state.curActiveChn._id,0);
        }
    }
    searchMessages(e,searchText,skip){
    //    if(e.target.value === this.state.searchQuery){
    //        return;
    //    }
    var comp = this;
    console.log("srarch msg this.state.searchQuery:",searchText);
        if(searchText.length){ 
            if(comp.state.authenticated){
                if(!skip){
                    comp.setState({
                        posts:[]//prevent lazy load states , set 0 message on first time search
                    });  
                    comp.socket.emit(eventsUtil.getSearch,{
                        channelId: comp.state.curActiveChn._id,
                        searchKey:searchText,
                        skip:0
                    });
                }else{
                    
                this.socket.emit(eventsUtil.getSearch,{
                    channelId: comp.state.curActiveChn._id,
                    searchKey:searchText,
                    skip:skip
                });
            }
            }
            e.preventDefault();
        }else{
           e.preventDefault();
        }
      } 
      
      handlePostScroll(event){
        
        let comp = this;
        if(comp.state.checkScrollPos){
            comp.setState({
                checkScrollPos:false
            });
            return;
        }else{
            if(comp.state.noDataOnLazyLd){
                return;
            }
            if(event.currentTarget.scrollTop < (event.currentTarget.clientHeight - 515)){
                event.currentTarget.scrollTop = event.currentTarget.scrollTop + 15;
                let skip;
                skip = comp.state.skip+5;
                comp.setState({
                    skip:skip,
                    checkScrollPos:true,
                    lazyLoadCall:true
                });
                if(!comp.state.searchQuery){
                     comp.getMessages(comp.state.curActiveChn._id,skip);
                }else{
                    comp.searchMessages(event,comp.state.searchQuery,skip);
                }
                
                event.preventDefault();
            }
        }
            
      }
      readUnreadMsg(event,msg){
          if(this.state.authenticated){
              if(!msg.readFlag){
                msg.readFlag = true;
                this.setState({
                    posts:this.state.posts
                })
                this.state.readMsgList.push(msg._id);
                setTimeout(
                    function() {
                        console.log("this.state lnt:",this.state.readMsgList.length);
                        if(this.state.readMsgList.length>0){
                            console.log("this.state:",this.state.readMsgList);
                            this.socket.emit(
                                'markAsRead', 
                                {
                                    messageId:this.state.readMsgList,
                                    user_id:msg.userId.user_id
                                }
                            );
                            this.setState({
                                readMsgList:[]
                            })
                        }
                    }
                    .bind(this),
                    5000
                );                    
            }
            }
      }
    render() {
        return (
            <div className = {styles.discussionOuterWrapper}>
                <div className = {(!this.state.expandMsgSec && !this.state.showDescription)  ?styles.discussionTocOuterWrap:styles.discussionTocOuterWrapChngd}>
                    <div className = {styles.discussionTocWrap}>
                        <section className = {styles.leftContInnerBlock}>
                            <Topics
                                channels = {this.state.channels}
                                handleTopicClick = { this.handleTopicClick }
                                openNewTopicPopup = {this.openNewTopicPopup}
                                handleChannelDelete = {this.handleChannelDelete}
                                enableCreate = {this.props.enableCreate}
                                activeChannel = {this.state.activeChannel}
                                topicListLoader = {this.state.topicListLoader}
                            />
                        </section>
                        <section className = {styles.leftContInnerBlock}>
                            <Users
                                users = {this.state.channelUsers}
                                handleUserClick = {this.handleUserClick}
                                openNewUser = {this.openNewUser}
                                enableCreate = {this.props.enableCreate}
                                activeUser = {this.state.activeUser}
                                curActiveChn = {this.state.curActiveChn}
                                userListLoader = {this.state.userListLoader}
                                handleUserDelete = {this.handleUserDelete}
                            />
                        </section>
                    </div>
                </div>
                <div className = {(!this.state.expandMsgSec || this.state.showDescription)?styles.discussionMessageOuterWrap:styles.discussionMessageOuterWrapChngd}>
                     <div className = {styles.discussionMessageWrap}>
                        <section className = {styles.discussionPostedMessageListWrap}>
                            <Posts
                                posts = { this.state.posts }
                                addMessage = { this.addMessage }
                                curActiveChn = {this.state.curActiveChn}
                                expandPostSec = {this.expandPostSec}
                                expandMsgSec = {this.state.expandMsgSec}
                                showDescription = {this.state.showDescription}
                                showDescriptionSec = {this.showDescriptionSec}
                                searchQuery =  {this.state.searchQuery}
                                handleSearchInputChange = {this.handleSearchInputChange} 
                                searchMessages = {this.searchMessages}
                                handlePostScroll  = {this.handlePostScroll}
                                lazyLoadCall={this.state.lazyLoadCall}
                                readUnreadMsg = {this.readUnreadMsg}
                                postSecLoader = {this.state.postSecLoader}
                                actvTopicName = {this.state.actvTopicName}
                            />
                        </section>
                        <section className = {styles.rightContInnerBlock}>
                        <div className={styles.paddingPostBox} >
                            <PostBox 
                                addMessage = {this.addMessage}
                            />
                        </div>
                        </section>
                    </div>
                    
                </div>
                <div className = {(this.state.showDescription) ? styles.discsnDescriptionOuterWrap : styles.discsnDescriptionOuterWrapChngd}>
                     <div className = {styles.discsnDescriptionWrap}>
                    <Description
                        curActiveChn = {this.state.curActiveChn}
                        showDescriptionSec = {this.showDescriptionSec}
                    />
                    </div>
                </div>
                {
                    this.state.showPopup ? 
                    <Popup
                        text='Close Me'
                    > 
                        <AddTopic
                            closePopup={this.togglePopup.bind(this)}
                            handleAddNewTopic = {this.handleAddNewTopic}
                        />
                    </Popup>
                    :
                    null
                }
                {
                    this.state.showUserPopup ? 
                    <Popup
                        text='Close Me'
                        
                    > 
                        <AddUser
                            closePopup={this.toggleUserPopup.bind(this)}
                            handleAddNewUser = {this.handleAddNewUser}
                            users = {this.state.users}
                            channelUsers = {this.state.channelUsers}
                            channel = {this.state.curActiveChn}
                        />
                    </Popup>
                    :
                    null
                }
                <NotificationContainer/>
            </div>
        );
    }
}

export default DiscussionForum;