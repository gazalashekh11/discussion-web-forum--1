import React, { Component } from 'react';
import Post from './post';
// import PostBox from '../postBox/postbox';
// import styles from './post.css';
// import ForumContext from '../context';
import eventsUtil from "../eventsUtil";
// import ChevronLeft from '@material-ui/icons/ChevronLeft';


class Messages extends Component {
  render(){
      return (
        <ul>
            {
            this.props.posts.map((object, i) => 
                <li key={object._id}>
                    <Post  
                        //showHideState = {this.state.commentBoxStates[comment._id]} 
                        post={object} 
                        //showHideReplyPopUp={this.showHideReplyPopUp} 
                        //socketEmit = {this.props.socketEmit}
                        //socketOn = {this.props.socketOn}
                        //hideReplyBtn = {this.state.hideReplyBtn}
                        //showReplySearchOff = {this.props.showReplySearchOff}
                        dateFormat = {eventsUtil.dateFormat}
                        timezone = {eventsUtil.globalTimezone}
                        timeFormat = {eventsUtil.timeFormat}
                        dateTimeFormat = {eventsUtil.dateTimeFormat}
                    />
                </li>
             )
            }
        </ul>
    )
  }
}

export default Messages;
