import React from 'react';
import styles from './posts.css';
import PostBox from "../postBox/postbox";
import ReplyBtn from '@material-ui/icons/Reply';

function Reply(props) {
   return (
       <div>
             <div className={((props.post.parent != null) || (props.hideReplyBtn)) ? styles.hideReplyBtn: styles.replySec}>
                <button className={styles.replyButton} onClick={event=>props.showHideReplyPopUp(event, props.post,"reply")}>
                    <ReplyBtn name='reply' className={styles.replyIcon} ></ReplyBtn>                
                </button>
            </div>
            {props.showHideState && 
            <div className={!props.hideReplyBtn ? styles.hideReplyPostbox: styles.paddingPostBox} >
                <PostBox 
                    post={props.post} 
                    parent =  {props.post._id}
                    addMessage = {props.addMessage}
                    showHideReplyPopUp={props.showHideReplyPopUp}
                    showHideReplyPostBox = {props.showHideState}
                />
            </div>
            }
        </div>
    );
}

export default Reply;
