import React from 'react';
import Comments from './comments';
import SearchMsg from "../searchMsg/searchMsg";
import styles from "./posts.css";
import ChevronLeft from '@material-ui/icons/ChevronLeft';
import Settings from '@material-ui/icons/Settings';
import CircularProgress from '@material-ui/core/CircularProgress';

function Posts(props) {
    //console.log("messages posts componenet:",props.posts);
    return(
        <div className = {(!props.expandMsgSec || props.showDescription) ? styles.collapsePost:styles.expandPost}>
             <section className={`${styles.topicTitle} ${styles.postPadding}`}>
                <ChevronLeft className={styles.toggleIcon}
                    name='chevron-left'
                    size={35}
                    onClick = {props.expandPostSec}>
                </ChevronLeft>
                  <span>{props.actvTopicName}</span>  
                  <SearchMsg 
                    curActiveChn = {props.curActiveChn}
                    searchQuery =  {props.searchQuery}
                    handleSearchInputChange = {props.handleSearchInputChange}
                    setSearchQuery = {props.setSearchQuery}
                    searchMessages = {props.searchMessages}
                  /> 
                  <Settings className={styles.setting}
                    name='setting'
                    size={35}
                    onClick = {props.showDescriptionSec}>
                </Settings>   
            </section>
            {props.postSecLoader ? <section className={styles.loader}>
            <CircularProgress  />
            </section>:
            
            <section className={styles.postSection} onScroll={event=>props.handlePostScroll(event)}>
            <Comments 
                      posts = {props.posts}
                      addMessage = {props.addMessage}
                      curActiveChn = {props.curActiveChn}
                      lazyLoadCall = {props.lazyLoadCall}
                      readUnreadMsg = {props.readUnreadMsg}
                   />
               
             </section>
            }
        </div>
    )
}

export default Posts;
