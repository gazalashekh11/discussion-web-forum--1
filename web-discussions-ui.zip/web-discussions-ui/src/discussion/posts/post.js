import React from 'react';
import styles from "./posts.css";
import Reply from './reply';
import Datetime from './datetime';
import ReadMsg from '@material-ui/icons/Check';

function Post(props){
    return(
        <div className={styles.post}>
        <Datetime callFrom = "parentDate" post = {props.post} />
            <div className={styles.postPadding} onMouseEnter = {event=>props.readUnreadMsg(event, props.post)}> 
                <span className = {styles.titleImg}>
                    <span>{props.post.userId.displayName.charAt(0)} </span>
                </span>
                <div className = {styles.postData}>
                <Datetime callFrom = "parentChildDate" post = {props.post} /> 
                    <div className={styles.postedMessage}>
                        <div 
                            className={(props.post.parent != null)?'':styles.postedMessage}
                        >
                            <article  dangerouslySetInnerHTML={{__html: `${props.post.text}`}} />
                        </div>
                    </div>
                </div>
                {/* {props.post.readFlag?
                <div>{props.post.readFlag}
                    <ReadMsg name='check' className={styles.readFalg} ></ReadMsg>   
                </div>:'hey'} */}
                <div className={props.post.readFlag ? '':styles.hideCheck}>
                    <ReadMsg name='check' className={(props.post.parent != null)?styles.readFlagChild:styles.readFlag} ></ReadMsg>   
                </div>
            </div>
            <Reply 
                post = {props.post}
                addMessage = {props.addMessage}
                showHideReplyPopUp= {props.showHideReplyPopUp}
                hideReplyBtn = {props.hideReplyBtn}
                showHideState = {props.showHideState}
            />
        </div>
    )
}

export default Post;