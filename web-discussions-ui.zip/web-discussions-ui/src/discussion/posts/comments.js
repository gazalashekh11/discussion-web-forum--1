import React, { Component } from 'react';
import Post from './post';
import styles from './posts.css';


class Comments extends Component {
    constructor(){
      super();
      this.state = {
        commentBoxStates:[],
        hideReplyBtn: false
      }
      this.showHideReplyPopUp = this.showHideReplyPopUp.bind(this);
      
    }
    showHideReplyPopUp(event, object,clickFrom){
      let newCommentBoxStates = {};
      Object.assign(this.state.commentBoxStates, newCommentBoxStates);
      newCommentBoxStates[object._id] = !newCommentBoxStates[object._id];
      this.setState({
        commentBoxStates : newCommentBoxStates
      });
      if(clickFrom === "reply"){
        this.setState({
          hideReplyBtn : true
        });
      }else{
        this.setState({
          hideReplyBtn : false
        });
      }
    }
    
    componentDidMount(){
      if(!this.props.lazyLoadCall){
      this.messagesEnd.scrollIntoView(false);
      }
    }
    render() {
        return (
          <div >
            <div style={{ float:"left", clear: "both" }}
                        ref={(el) => { this.messagesEnd = el; }}>
                    </div>
            <ul>
                {
                    this.props.posts.map(
                        (object, i) => 
                        <li  
                            key={object._id} 
                        > 
                          <div key={object._id} 
                             className={[((object.parent != null)?styles.postedMessageChildSec:''),styles.postedMessageSec].join(' ')}
                          >
                              <Post 
                                  post = {object}
                                  addMessage = {this.props.addMessage}
                                  showHideReplyPopUp= {this.showHideReplyPopUp}
                                  hideReplyBtn = {this.state.hideReplyBtn}
                                  showHideState = {this.state.commentBoxStates[object._id]}
                                  readUnreadMsg = {this.props.readUnreadMsg}
                              />
                              {
                                // object.comments && object.comments.length&&
                                object.comments &&
                                <div className={styles.comment}>
                                  <Comments
                                    posts = {object.comments}
                                    addMessage = {this.props.addMessage}
                                    lazyLoadCall = {this.props.lazyLoadCall}
                                    readUnreadMsg = {this.props.readUnreadMsg}
                                  />
                                </div>
                              }
                              </div>
                        </li>
                    )
                }
            </ul>
        </div>
        
      )
    }
  }
  export default Comments;