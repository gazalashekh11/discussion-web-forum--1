import React from 'react';
import styles from './post.css';
import Moment from 'react-moment';
import moment from 'moment-timezone';
import mom from 'moment';
import eventsUtil from "../eventsUtil";
var tz = moment.tz.guess();
var preDate , currDate , msgDate = '',msgChildDate=''; 
function Datetime(props) {
    
    Moment.globalFormat = eventsUtil.dateFormat;
    if(props.post.parent === undefined) {
        preDate = currDate;
        msgDate = parseInt(props.post._id.toString().substring(0,8), 16 ) * 1000; 
        currDate = mom(msgDate).format(eventsUtil.dateFormat);
    }  
    msgChildDate = parseInt(props.post._id.toString().substring(0,8), 16 ) * 1000;
   return (
       <div>
           {(props.callFrom === "parentDate")&&
            <span>{(props.post._id && currDate!== preDate && props.post.parent === undefined) ?
                  <div className={styles.dateWithLine}>
                    <span className={(props.post.parent !== undefined)? styles.HideTimeOnly:''}> <Moment tz={tz}>{msgDate}</Moment></span>
                </div> : '' }</span>}
            {(props.callFrom === "parentChildDate")&&   
            <div className={styles.postedMsgTitleTime}>
                <h3 className={styles.postedTitle}>{props.post.userId.displayName }
                    <span className={(props.post.parent === undefined)? styles.timeOnly: styles.HideTimeOnly}><Moment tz={tz} format={eventsUtil.timeFormat}>{msgChildDate}</Moment> </span>
                    <span className={(props.post.parent !== undefined)? styles.timeOnly: styles.HideTimeOnly}><Moment tz={tz} format={eventsUtil.dateTimeFormat}>{msgChildDate}</Moment> </span>
                    </h3>           
            </div> 
           }
        </div>
    );
}

export default Datetime;
