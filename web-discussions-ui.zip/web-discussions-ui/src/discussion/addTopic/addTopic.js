import React from 'react';
import styles from './addTopic.css';
import Close from '@material-ui/icons/Clear';

class AddTopic extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      topicName: "",
      topicDescription: "",
      topicOrganization: props.organization,
      implicit: "no"
    }
    this.handleChange = this.handleChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
  }
  handleChange(event){
    const target = event.target;
    const value = target.type === 'checkbox' ? target.checked : target.value;
    const name = target.name;
    if(name === "topicName"){
        if(event.target.value.match("^[a-zA-Z]") != null){
          this.setState({
            [name]: value
          });
      }
      if(event.target.value.length === 0){
        this.setState({
          [name]: value
        });
    }
    }else{
      this.setState({
        [name]: value
      });
    }

    
  }
  handleSubmit(event) {
    event.preventDefault();
    if(!this.state.topicName.length || !this.state.topicDescription.length){
      return;
    }
    this.props.handleAddNewTopic(
      {
        name: this.state.topicName, 
        description: this.state.topicDescription,
        implicit: this.state.implicit
      }
    );
    this.props.closePopup();
  }
  
  render() {
    return (
      <div className={styles.addTopic} >
      <div className={styles.modalHeader}>
      <span aria-hidden="true" className={styles.closeModal} onClick={this.props.closePopup}>
        <Close
        name='clear'
        size={32}
        
      />
    </span>
      <h4 className={styles.titleModal}>  New Discussion</h4>
      
      </div>
        <form onSubmit={this.handleSubmit} className={styles.formModal}>
           <div className={styles.fieldsSection}>
            <label 
              htmlFor="topic" className={styles.labelText}>
              Topic
              <span className= {styles.topicLength}>{this.state.topicName.length} / 25</span>
            </label>
            <input 
              className={styles.inputAddTopic} 
              type="text" 
              id="topicName" 
              name="topicName" 
              placeholder="Topic.." 
              value={this.state.topicName}
              onChange={this.handleChange} 
              maxLength = "25"
              minLength = "3"              
            />
            <label 
              htmlFor="description" className={styles.labelText}>
              Description
            </label>
            <textarea 
              className={styles.inputAddDiscription} 
              type="text" 
              id="topicDescription" 
              name="topicDescription" 
              placeholder="Description.." 
              value={this.state.topicDescription}
              onChange={this.handleChange} 
            />
            <label 
              htmlFor="topic" className={styles.labelText}>
              Implicit Channel
            </label>
            <input 
              type="radio" 
              name="implicit" value="yes" 
              checked={this.state.implicit === 'yes'} 
              onChange={this.handleChange} /> Yes
            <input 
              type="radio" 
              name="implicit" 
              value="no" 
              checked={this.state.implicit === 'no'} 
              onChange={this.handleChange} /> No
            </div> 
            <div className={styles.buttonSection}>
              <button className={styles.cancelButton} onClick={this.props.closePopup}>Cancel</button>
              <button 
                className=  {((this.state.topicName.length > 2 ) && (this.state.topicDescription.length > 0 )&&(this.state.topicGroup !== "")) ? styles.addTopicSumbit:styles.disabledButton } 
                type="submit" 
                value="Submit" disabled={!this.state.topicName}
              >Create Discussion</button>
            </div>
        </form>
        
      </div>
    );
  }
}

export default AddTopic;