import React from 'react';
import styles from './postBox.css';
import ReactQuill from 'react-quill';
import 'react-quill/dist/quill.snow.css';
import SendIcon from '@material-ui/icons/Send';

class PostBox extends React.Component {
  constructor(props){
    super(props);
    this.state = { text: '' };
    this.handleChange = this.handleChange.bind(this)
    this.handleSendMessage = this.handleSendMessage.bind(this);
    this.cancelPostMessage = this.cancelPostMessage.bind(this);
  }
  
  handleSendMessage(event) {
    if(this.state.text.length === 0 || this.state.text === "<p><br></p>" ){
      return;
    }
    if(this.props.showHideReplyPopUp){
      this.props.showHideReplyPopUp(event,this.props.post,"");
    }
    // this.props.addMessage(this.state.text, this.props.post._id);
    this.props.addMessage(this.state.text, this.props.parent);
    this.setState({ text: '' });
   }
   cancelPostMessage(event,post){
    this.props.showHideReplyPopUp(event,post,"notReply");   
     
 }
  handleChange(value) {
    this.setState({ text: value });
  }
  
  render(){

    return (
        <div>
            <ReactQuill 
            value={this.state.text}
            onChange={this.handleChange} 
            modules={PostBox.modules}
            formats={PostBox.formats}
            />
            <div className={!this.props.showHideReplyPostBox ? styles.mainPostBtn : styles.hideBtnSec}>
                      <button className={styles.submitPost}
                            onClick={(event) => this.handleSendMessage(event)}>
                         <SendIcon name="send-post" className={styles.sendIcon}></SendIcon>
                    </button>
                  </div>
                  <div className={!this.props.showHideReplyPostBox ? styles.hideBtnSec : styles.buttonSection} >
                    <button 
                    className={styles.cancelPostBtn} 
                    onClick={event=>this.cancelPostMessage(event, this.props.post)}>
                      Cancel {this.props.showHideReplyPostBox}
                      </button>
                    <button 
                        className={styles.sendPostBtn} 
                        onClick={(event) => this.handleSendMessage(event)}
                    >
                      Send
                    </button>
                    
                  </div>
            {/* <div className={styles.mainPostBtn}>
                <button className={styles.submitPost}
                    onClick={(event) => this.handleSendMessage(event)}>
                    <SendIcon name="send-post" className={styles.sendIcon}></SendIcon>
                </button>
            </div> */}
        </div>
      
    );
  }
}

PostBox.modules = {
  toolbar: [
    [{ 'header': '1'}, {'header': '2'}],
    [{size: []}],
    ['bold', 'italic', 'underline', 'strike', 'blockquote'],
    [{'list': 'ordered'}, {'list': 'bullet'}, 
     {'indent': '-1'}, {'indent': '+1'}],
    ['link'],
    ['clean']
  ],
  clipboard: {
    // toggle to add extra line breaks when pasting HTML:
    matchVisual: false,
  }
}
/* 
 * Quill editor formats
 * See https://quilljs.com/docs/formats/
 */
PostBox.formats = [
  'header', 'size',
  'bold', 'italic', 'underline', 'strike', 'blockquote',
  'list', 'bullet', 'indent',
  'link'
]
export default PostBox;
