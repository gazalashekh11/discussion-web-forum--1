import React from 'react';
import styles from './popup.css';

function Popup(props) {
  return (
      <div className={styles.popup}>
        <div className={styles.popup_inner}>
            {props.children}
            {/* <button onClick={this.props.closePopup}>close me</button> */}
        </div>
      </div>
    );
}

export default Popup;