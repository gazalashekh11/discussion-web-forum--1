import React, { Component } from 'react';
import Login from './login/login';
import DiscussionForum from './discussion/discussionForum';
import './App.css';

class App extends Component {
  constructor(){
    super();
    this.state = {
      userName: "",
      channelQuery:"",
      accessRW:"",
      currentOrg:"",
      authToken: "",
      enableCreate:0,
      schoolId:"",
      showLogin: true
    }
    this.onLogin = this.onLogin.bind(this);
    this.setEnableCreate = this.setEnableCreate.bind(this);
  }
  onLogin(event, obj){
    this.setState({
        userName: obj.userName, 
        channelQuery: obj.channelQuery, 
        accessRW: obj.accessRW,
        currentOrg: obj.currentOrg,
        enableCreate : obj.enableCreate,
        authToken: obj.authToken,
        schoolId: obj.schoolId,
        showLogin: false
      })
  }
  setEnableCreate(val){
    this.setState({
      enableCreate:val
    });
  }
  render() {
    return (
      <div className="App">
        {
          this.state.showLogin 
          ?
          <Login 
            onLogin = {this.onLogin} 
          />
          :
          null
        }
        {
          !this.state.showLogin 
          ?
          <DiscussionForum 
            userName = {this.state.userName}
            channelQuery = {this.state.channelQuery}
            accessRW = {this.state.accessRW}
            currentOrg = {this.state.currentOrg}
            authToken = {this.state.authToken}
            enableCreate = {this.state.enableCreate}
            setEnableCreate = {this.setEnableCreate}
            schoolId={this.state.schoolId}
          />
          :
          null
        }
      </div>
    );
  }
}

export default App;
