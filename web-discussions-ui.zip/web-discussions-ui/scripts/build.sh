#!/bin/bash
node --version
npm --version
npm install